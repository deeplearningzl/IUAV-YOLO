import warnings

warnings.filterwarnings('ignore')
from ultralytics import YOLOv10

if __name__ == '__main__':
    model = YOLOv10(r'/root/AI666v10yuan/runs/train/exp6/weights/best.pt')
    model.val(data=r'UAVB_811.yaml',
              split='test',
              imgsz=640,
              batch=32,
              # rect=False,
              # save_json=True, # 这个保存coco精度指标的开关
              project='runs/test',
              name='exp',
              )