from ultralytics import YOLOv10

model = YOLOv10(r'D:\CNNlearning\yolov10-main\exptrain\weights\best.pt')
# or
# model = YOLOv10.from_pretrained('jameslahm/yolov10{n/s/m/b/l/x}.pt')

model.predict(r"E:\guoyuan_exp\changbo_drone\ir_1.mp4",show=False,save=True,imgsz=640,conf=0.25)