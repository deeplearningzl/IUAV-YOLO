import warnings

warnings.filterwarnings('ignore')
from ultralytics import YOLOv10

if __name__ == '__main__':
    model = YOLOv10(r'/root/AI666v10yuan/ultralytics/cfg/models/v10/v10n_FEM.yaml')
    # model.load('yolov8n.pt') # loading pretrain weights
    model.train(data='UAVB_811.yaml',
                # 如果大家任务是其它的'ultralytics/cfg/default.yaml'找到这里修改task可以改成detect, segment, classify, pose
                imgsz=640,
                epochs=700,
                single_cls=False,  # 是否是单类别检测
                batch=32,
                patience=70,
                close_mosaic=10,
                workers=16,
                device='0',
                optimizer='auto',  # using SGD
                # resume='', # 如过想续训就设置last.pt的地址
                amp=True,  # 如果出现训练损失为Nan可以关闭amp
                project='runs/train',
                name='exp',
                )
