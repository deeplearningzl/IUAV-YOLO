# import numpy as np
from ultralytics import YOLO
# import sys
# import argparse
# import os

# from ultralytics import YOLO

# def main(opt):
#     yaml = opt.cfg

#     model = YOLO(model='/root/AI666v10/runs/train/exp/weights/best.pt')

#     model.predict(source='/root/autodl-tmp/drone_all_5/images/test', save=True, imgsz=640, conf=0.5, save_txt=True, save_conf=True)


# def parse_opt(known=False):
#     parser = argparse.ArgumentParser()
#     parser.add_argument('--cfg', type=str, default=r'AI666v10/runs/train/exp/weights/best.pt', help='initial weights path')
#     parser.add_argument('--artifact_alias', type=str, default='latest', help='W&B: Version of dataset artifact to use')

#     opt = parser.parse_known_args()[0] if known else parser.parse_args()
#     return opt

# if __name__ == "__main__":
#     opt = parse_opt()
#     main(opt)
model = YOLO(r'/root/ultralytics-8.3.0/runs/train/exp26/weights/best.pt')
# or
# model = YOLOv10.from_pretrained('jameslahm/yolov10{n/s/m/b/l/x}.pt')

model.predict(source=r"/root/autodl-tmp/drone_all_5/images/test",show=False,save=True,imgsz=640,conf=0.25,visualize = False)