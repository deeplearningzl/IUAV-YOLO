import torch
import torch.nn as nn

class SiLU(nn.Module):
    @staticmethod
    def forward(x):
        return x * torch.sigmoid(x)

class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6

class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)

def get_activation(name="silu", inplace=True):
    if name == "silu":
        module = SiLU()
    elif name == "relu":
        module = nn.ReLU(inplace=inplace)
    elif name == "lrelu":
        module = nn.LeakyReLU(0.1, inplace=inplace)
    else:
        raise AttributeError("Unsupported act type: {}".format(name))
    return module

class BaseConv(nn.Module):
    def __init__(self, in_channels, out_channels, ksize, stride, groups=1, bias=False, act="silu"):
        super().__init__()
        pad = (ksize - 1) // 2
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=ksize, stride=stride, padding=pad, groups=groups, bias=bias)
        self.bn = nn.InstanceNorm2d(out_channels, eps=0.001)  # 使用 InstanceNorm2d
        self.act = get_activation(act, inplace=True)

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def fuseforward(self, x):
        return self.act(self.conv(x))

class ContextAggregation(nn.Module):
    def __init__(self, in_channels, reduction=1):
        super(ContextAggregation, self).__init__()
        self.in_channels = in_channels
        self.reduction = reduction
        self.inter_channels = max(in_channels // reduction, 1)

        conv_params = dict(ksize=1, stride=1, groups=1, bias=False, act="silu")

        self.a = BaseConv(in_channels, 1, **conv_params)
        self.k = BaseConv(in_channels, 1, **conv_params)
        self.v = BaseConv(in_channels, self.inter_channels, **conv_params)
        self.m = BaseConv(self.inter_channels, in_channels, **conv_params)

        self.init_weights()

    def init_weights(self):
        for m in (self.a, self.k, self.v):
            nn.init.xavier_uniform_(m.conv.weight)
        nn.init.constant_(self.m.conv.weight, 0)

    def forward(self, x):
        n = x.size(0)
        c = self.inter_channels

        a = self.a(x).sigmoid()
        k = self.k(x).view(n, 1, -1, 1).softmax(2)
        v = self.v(x).view(n, 1, c, -1)

        y = torch.matmul(v, k).view(n, c, 1, 1)
        y = self.m(y) * a

        return x + y

class ModifiedSPPF(nn.Module):
    def __init__(self, c1, c2, k=5):
        super().__init__()
        c_ = c1 // 2
        self.cv1 = BaseConv(c1, c_, 1, 1)
        self.cv2 = BaseConv(c_ * 6, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)
        self.am = nn.AdaptiveMaxPool2d(1)
        self.aa = nn.AdaptiveAvgPool2d(1)
        self.additional_conv = BaseConv(c_, c_, 3, 1)  # 添加额外的卷积层
        self.attention = ContextAggregation(c_ * 6)

    def forward(self, x):
        x = self.cv1(x)
        x = self.additional_conv(x)  # 通过额外的卷积层改变输入尺寸
        y1 = self.m(x)
        y2 = self.m(y1)
        y3 = self.m(y2)
        y4 = self.am(x).expand_as(x)
        y5 = self.aa(x).expand_as(x)
        aggregated = torch.cat((x, y1, y2, y3, y4, y5), 1)
        aggregated = self.attention(aggregated)
        return self.cv2(aggregated)

# 示例代码
model = ModifiedSPPF(c1=64, c2=128, k=5)
input_tensor = torch.randn(1, 64, 32, 32)  # 假设输入张量形状为 (1, 64, 32, 32)
output_tensor = model(input_tensor)
print(output_tensor.shape)  # 输出张量形状
